<html>
<head>
<script type='text/javascript' src='http://grevador.net/forums/applications/cms/interface/external/external.js' id='ipsWidgetLoader'></script><link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<script type="text/javascript">
    var vglnk = {key: '6dd957172988ea2866075a6f5f4f0072'};
    (function(d, t) {
        var s = d.createElement(t);
            s.type = 'text/javascript';
            s.async = true;
            s.src = '//cdn.viglink.com/api/vglnk.js';
        var r = d.getElementsByTagName(t)[0];
            r.parentNode.insertBefore(s, r);
    }(document, 'script'));
</script>
<header class="main-header">
     <div class="logo">
		<img src="imgs/logo.png">
	 </div>
	<a href="Grevador.jar" class="play-button"></a>
  </header>
<nav>
    <ul class="nav" id="main-nav">
      <li class="nav-link"><a href="/forums/">Community</a></li>
      <li class="nav-link"><a href="http://www.grevador.org/donate.html">Store</a></li>
      <li class="nav-link"><a href="http://www.grevador.org/vote.html">Vote</a></li>
      <li class="nav-link"><a href="http://www.grevador.org/highscores.html">Hiscores</a></li>
    </ul>
  </nav>
  <center>
        <iframe width="75%" height="100%" frameborder="0" src="http://www.grevadorps317.everythingrs.com/services/hiscores" />
			</center>
		</div>
		<div class="right-side">
					<section class="side-content-box">
				 <header>
					<h1 class="section-title">Players Online</h1> 
				</header>
				  <div class="side-content-container">
				      
					Players Online: <font color=green>						
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
<script type="text/javascript">
    var accountName = "L3WK";
    $.get("https://everythingrs.com/api/players-online/get/" + accountName, function(response) {
        $("#players").html(response);
    });

</script>
<span id="players"></span> 

				  </div>
			</section>
			
			<section class="side-content-box">
				 <header>
					<h1 class="section-title">Join Grevador on Discord!</h1> 
				</header>
				  <div class="side-content-container">
					   <iframe  scrolling="yes" height="221px" src="discord/index.html?serverID=678294836977336330&amp;theme=dark&amp;invite=true" frameborder="0" allowfullscreen="allowfullscreen"></iframe>
				  </div>
			</section>
		</div>

	</div>
	
		<footer id='ipsLayout_footer'>
          <div class='ipsLayout_container'>
            <div class="giel_footer">
			
            <div style="width:60%">
                <h1>Grevador</h1>
                <p>Trademarks and brands are the property of their respective owners.</p>
                <p> Grevador is not affiliated with Jagex, RuneScape or Funorb.</p>
                <p> To play RuneScape, visit <a href="http://runescape.com">RuneScape.com.</a></p>
            </div>
            <div style="width:20%;">
                <div class="footer_wrapper">
                    <ul>
                        <li>Grevador</li>
                        <li><a href="Grevador.jar">Play Grevador</a></li>
                        <li><a href="/forums">Community Forums</a></li>
                        <li><a href="http://www.grevador.org/donate.html">Visit Store</a></li>
                        <li><a href="/vote">Vote for us</a></li>
                        <li><a href="/highscores">Highscores</a></li>
                    </ul>
                </div>
            </div>
            <div style="width:20%;">
                <div class="footer_wrapper">
                    <ul>
                        <li>Community</li>
                        <li><a href="http://grevador.net/forums/index.php?/register/">Login/Register</a></li>
                        <li><a href="http://grevador.net/forums/index.php?/forum/4-announcements/">Announcements</a></li>
                        <li><a href="http://grevador.net/forums/index.php?/forum/5-updates/">Game Updates</a></li>
                        <li><a href="http://grevador.net/forums/index.php?/forum/13-guides/">Game Guides</a></li>
                        <li><a href="http://grevador.net/forums/index.php?/forum/6-knowledge-base/">Knowledge Base</a></li>
                    </ul>
                </div>
            </div>
           <div style="width:20%;">
                <div class="footer_wrapper">
                    <ul>
                        <li>Social</li>
                        <li><a href="https://discord.gg/2ADJBhJ"><img src="https://i.imgur.com/rJ50VGT.png" alt="Discord"></a></li>
                    </ul>
                </div>
            </div>
            </div>
          </div>

		</footer>

  
  </body>
  
  </html>