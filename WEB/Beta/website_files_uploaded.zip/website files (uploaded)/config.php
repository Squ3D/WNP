<?php $Players = file_get_contents("players.txt");?>
 <script>
var auto_refresh = setInterval(
function ()
{
	jQuery.get('http://grevador.net/players.txt', function(data) {
    $('#PlayCount').text(data);
	
});
}, 10); // refresh
  </script>